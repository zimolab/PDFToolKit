FONT_FAMILY = "Consolas, monospace, Monaco, Source Code Pro, Inter, Arial, sans-serif;"
FONT_SIZE_CODE_TEXT = 16
