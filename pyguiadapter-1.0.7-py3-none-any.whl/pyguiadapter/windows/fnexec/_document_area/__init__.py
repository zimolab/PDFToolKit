from .area import DocumentArea
