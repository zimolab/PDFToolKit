from .document_browser import DocumentBrowserConfig

__all__ = [
    "DocumentBrowserConfig",
]
